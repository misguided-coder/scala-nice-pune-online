object FunctionsDemo {
	def main(args:Array[String]) {
		hello()
		hi()
		gm()

		hello
		hi
		gm
				
		greet("Billu",30)
		
		greetMe("Billu")
		greetMe("Billu",21) //passing arguments by position
		greetMe(name="Billu",age=21) //passing arguments by name 
		greetMe(age=21,name="Billu") //passing arguments by name 

		var rs = generate()
		println(rs)

		rs = generateSeq()
		println(rs)

		//rs = generateUnique()
		rs = generateUnique
		println(rs)

		rs = generateValue
		println(rs)
	}

	//named functions with return values 
	//def generateValue:Int = { 590/2-50; }
	def generateValue:Int = 590/2-50  //UAP --- Unified Access Protocol
	
	//named functions with return values 
	//def generateUnique():Int = {
	def generateUnique:Int = {
		500/2-50;
	}


	//named functions with return values 
	def generateSeq():Int = {
		println("Generating a value....")
		println("Generating a value....")
		println("Generating a value....")
		println("Generating a value....")
		println("Generating a value....")
		println("Generating a value....")
		println("Generating a value....")
		500/2;
	}


	//named functions with return values 
	//def generate():Unit = {
	//def generate() = {
	def generate():Int = {
		println("Generating a value....")
		return 210;
	}


	//named functions with arguments default/optional values
	def greetMe(name:String,age:Int = 10) {
		println("Good Evening "+name)
		println("You are "+age+" yrs old.")
		//500 LOC
	}

	//named functions with arguments
	def greet(name:String,age:Int) {
		println("Good Evening "+name)
		println("You are "+age+" yrs old.")
		//500 LOC
	}	

	//named functions
	def gm() {
		println("Good Morning All")
	}	

	//named functions
	def hi() = {
		println("Hi All")
	}	

	//named functions
	def hello():Unit = {
		println("Hello All")
	}	

}


