def hi() {
	println("Welcome to Scalable Language!!");
	println("Is is a functional Language!!");
}


hi()