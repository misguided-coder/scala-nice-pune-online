object ConditionsDemo {
	def main(args:Array[String]) {
				
		//UC1()
		//UC2_Java()
		//UC2_Scala()
		//UC3()
		//UC4()
		//UC5()
		UC6()
	}

	def UC6() {

		var result = ""
		
		val color = "Green"
		//val color = "White"

		result  = color match  {
			case "Black" => 
				"Black is beautiful"
			case "Blue" => 
				"Blue is cool"
			case "Green" => 
				"Green in better"
			case default => 
				"Unknown color"
		}

		println("COLOR FOUND : "+result);
	}


	def UC5() {
		
		//val color = "Green"
		val color = "White"

		color match  {
			case "Black" => 
				println("Black is beautiful")
			case "Blue" => 
				println("Blue is cool")
			case "Green" => 
				println("Green in better")
			case default => 
				println("Unknown color")
		}	
	}



	//Java Way
	def UC2_Java() {
		var result = ""
		val age = 25
		
		if(age <= 20)
			 result = "You are young"
		else 
			 result = "You are not young"

		println(result);
	}


	//Scala Way
	//condtions in Scala work like functions
	def UC2_Scala() {
		var result = ""
		val age = 25
		
		result = if(age <= 20) {
				println("Hey....")
				"You are young"
			 } else {
				println("Hey....")
				"You are not young"
			 }

		println(result);
	}


	def UC1() {
		val age = 20
		if(age <= 20)
			println("You are young");
		else 
			println("You are not young");
	}

}