object DataTypeDemo {
	def main(args:Array[String]) {
		
		//package name is "scala"
		//Byte,Short,Int,Long for numeric data
		//Float,Double for decimal data
		//Char for letters 
		//Boolean for true/false 

		//mutable data
		var age = 24  //data type inference 
		println(age);
		println(age.getClass());
		age = 30
		println(age);
		println(age.getClass());

		//mutable data
		var pages:Int = 450  //explicit data type
		println(pages);
		println(pages.getClass());
		pages = 500 
		println(pages);
		println(pages.getClass)

		//immutable data
		val marks = 500  //data type inference 
		println(marks);
		println(marks.getClass());

		//marks = 1000  //data type inference //will not work
		//println(marks);
		//println(marks.getClass());

		
		var data:Any = 4000
		println(data);
		println(data.getClass());
		data = "Hello...."
		println(data);
		println(data.getClass());


		var some:AnyVal = 20
		println(some);
		println(some.getClass());

		var other:AnyRef = new java.util.Date()
		println(other);
		println(other.getClass());

		//var more:Any = new java.util.Date()
		var more:Any = 450.90
		println(more);
		println(more.getClass());

	}
}