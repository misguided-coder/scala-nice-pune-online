object LoopsDemo {
	def main(args:Array[String]) {
				
		//UC1()
		//UC2()
		UC3()
	}

	def UC3() {
		for(data <- 5 to 20) {
			println("Loop "+data)
		}
	}


	def UC2() {
		
		var idx = 0
		do {		
			println("Loop "+idx)
			idx = idx + 1	
		} while(idx < 5)
		
	}


	def UC1() {
		
		var idx = 0
		while(idx < 5) {		
			println("Loop "+idx)
			idx = idx + 1	
		}
		
	}

}