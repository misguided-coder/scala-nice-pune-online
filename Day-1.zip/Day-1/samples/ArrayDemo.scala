object DataTypeDemo {
	def main(args:Array[String]) {
				
		//UC1()
		//UC2()
		//UC3()
		UC4()
	}


	def UC4() {
				
		//initialize primary array 
	 	var numbers = Array.ofDim[Int](4,4)
		
		//polulate array column values
		numbers(0)(0) = 10
		numbers(0)(1) = 20
		numbers(0)(2) = 30
		numbers(0)(3) = 30

		numbers(1)(0) = 10
		numbers(1)(1) = 20
		numbers(1)(2) = 30
		numbers(1)(3) = 30

		println(numbers(1)(2));
		println(numbers(0)(0));

	}


	def UC3() {
				
		//initialize primary array 
		//var numbers:Array[Array[Int]] = new Array[Array[Int]](4)  //2D array
	 	var numbers = new Array[Array[Int]](4)  //2D array
		
		//initialize nested array 
		numbers(0) = new Array[Int](3)
		numbers(1) = new Array[Int](3)
		numbers(2) = new Array[Int](3)
		numbers(3) = new Array[Int](3)

		//polulate array column values
		numbers(0)(0) = 10
		numbers(0)(1) = 20
		numbers(0)(2) = 30

		numbers(1)(0) = 10
		numbers(1)(1) = 20
		numbers(1)(2) = 30


		numbers(2)(0) = 10
		numbers(2)(1) = 20
		numbers(2)(2) = 30


		numbers(3)(0) = 10
		numbers(3)(1) = 20
		numbers(3)(2) = 30


		println(numbers(1)(2));
		println(numbers(2)(0));

	}

	
	def UC2() {
				
		//array declaration and initialization
		var numbers = new Array[Int](4)  //data type inference
		//array population
		numbers(0) = 1000
		numbers(1) = 2000
		numbers(2) = 3000
		numbers(3) = 4000

		println(numbers);
		println(numbers(0));
		println(numbers(1));
		println(numbers(2));
		println(numbers(3));

	}



	def UC1() {
				
		//array declaration and initialization
		var numbers:Array[Int] = new Array[Int](4) //explicit data type
		//array population
		numbers(0) = 1000
		numbers(1) = 2000
		numbers(2) = 3000
		numbers(3) = 4000

		println(numbers);
		println(numbers(0));
		println(numbers(1));
		println(numbers(2));
		println(numbers(3));

	}

}