object Hello {
	def main(args:Array[String]) {
		println("Welcome to Scalable Language!!");
	}
}